#!/bin/bash

# Конфигурация
BACKUP_ROOT="/root/backup"
PROMETHEUS_GATEWAY="http://prometheus.vpn:9091"
METRICS_FILE="/var/lib/node_exporter/backup_metrics.prom"
LOG_FILE="/var/log/backup_validator.log"
MAX_LOG_FILES=5
MAX_LOG_SIZE=10M
MAX_AGE_HOURS=24
VALIDATE_ARCHIVE=true
MIN_BACKUP_COUNT=1
S3_BUCKET="backupsergeev"  # Имя бакета в Yandex Object Storage
S3_PREFIX="$HOSTNAME"       # Префикс для папки в S3 (необязательно)
YC_CLI="$HOME/yandex-cloud/bin/yc"      # Путь к yc CLI

# Инициализация логов
mkdir -p "$(dirname "$LOG_FILE")"
exec > >(tee -a "$LOG_FILE") 2>&1

# Функция ротации логов
rotate_logs() {
    if [ -f "$LOG_FILE" ] && [ $(stat -c%s "$LOG_FILE") -gt $(numfmt --from=iec "$MAX_LOG_SIZE") ]; then
        for i in $(seq $((MAX_LOG_FILES-1)) -1 1); do
            [ -f "${LOG_FILE}.$i" ] && mv "${LOG_FILE}.$i" "${LOG_FILE}.$((i+1))"
        done
        mv "$LOG_FILE" "${LOG_FILE}.1"
    fi
}

# Функция логирования с разными уровнями
log() {
    local level=$1
    local message=$2
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S,%3N")
    echo "[$timestamp] [$level] $message" | tee -a "$LOG_FILE"
}

# Функция проверки целостности архива
validate_archive() {
    local archive_path=$1
    log "DEBUG" "Проверка целостности архива: $archive_path"

    if ! tar -tzf "$archive_path" >/dev/null 2>&1; then
        log "ERROR" "Архив поврежден: $archive_path"
        return 1
    fi

    local file_count=$(tar -tzf "$archive_path" | wc -l)
    if [ "$file_count" -lt 5 ]; then
        log "WARNING" "Мало файлов в архиве ($file_count): $archive_path"
    fi
    return 0
}

# Функция загрузки в Yandex S3
upload_to_s3() {
    local file_path=$1
    local s3_destination="s3://${S3_BUCKET}/${S3_PREFIX}/$(basename "$file_path")"
    local max_retries=3
    local retry_delay=10

    for ((attempt=1; attempt<=max_retries; attempt++)); do
        log "INFO" "Попытка загрузки $attempt из $max_retries: $file_path -> $s3_destination"
        
        if $YC_CLI storage s3 cp "$file_path" "$s3_destination"; then
            log "INFO" "Файл успешно загружен в S3"
            return 0
        else
            log "WARNING" "Ошибка загрузки (попытка $attempt)"
            [ $attempt -lt $max_retries ] && sleep $retry_delay
        fi
    done

    log "ERROR" "Не удалось загрузить файл после $max_retries попыток"
    return 1
}

# Основная функция валидации и загрузки
validate_and_upload_backups() {
    local current_time=$(date +%s)
    local global_status=0
    local tmp_metrics=$(mktemp)
    local total_uploaded=0
    local total_failed=0

    # Заголовки метрик
    cat > "$tmp_metrics" <<EOF
# HELP backup_last_timestamp_seconds Timestamp of last backup
# TYPE backup_last_timestamp_seconds gauge
# HELP backup_status Backup status (1 - OK, 0 - problem)
# TYPE backup_status gauge
# HELP backup_age_seconds Age of last backup in seconds
# TYPE backup_age_seconds gauge
# HELP backup_size_bytes Size of last backup in bytes
# TYPE backup_size_bytes gauge
# HELP backup_count_total Number of backups for host
# TYPE backup_count_total gauge
# HELP backup_validation_result Archive validation result (1 - valid, 0 - invalid)
# TYPE backup_validation_result gauge
# HELP backup_s3_upload_status S3 upload status (1 - success, 0 - failed)
# TYPE backup_s3_upload_status gauge
EOF

    log "INFO" "Начало проверки бэкапов в $BACKUP_ROOT"

    # Обработка каждого каталога с бэкапами
    for host_dir in "$BACKUP_ROOT"/*; do
        [ -d "$host_dir" ] || continue

        local hostname=$(basename "$host_dir")
        local backups=($(find "$host_dir" -name "backup_${hostname}_*.tar.gz" -type f -printf "%T@ %p\n" | sort -nr | cut -d' ' -f2))
        local backup_count=${#backups[@]}
        local host_status=1
        local upload_status=0

        log "INFO" "Проверка хоста: $hostname (найдено бэкапов: $backup_count)"

        if [ "$backup_count" -lt "$MIN_BACKUP_COUNT" ]; then
            log "ERROR" "Недостаточно бэкапов для $hostname (ожидается $MIN_BACKUP_COUNT, найдено $backup_count)"
            host_status=0
        fi

        # Проверяем последний бэкап
        if [ "$backup_count" -gt 0 ]; then
            local latest_backup="${backups[0]}"
            local backup_time=$(stat -c %Y "$latest_backup")
            local backup_age=$((current_time - backup_time))
            local backup_size=$(stat -c %s "$latest_backup")
            local validation_result=1

            log "INFO" "Последний бэкап: $(basename "$latest_backup")"
            log "INFO" "Размер: $backup_size байт, возраст: $((backup_age/3600)) ч. $(( (backup_age%3600)/60 )) мин."

            # Проверка возраста
            if [ "$backup_age" -gt $((MAX_AGE_HOURS * 3600)) ]; then
                log "ERROR" "Бэкап слишком старый: $((backup_age/3600)) часов"
                host_status=0
            fi

            # Проверка целостности
            if [ "$VALIDATE_ARCHIVE" = true ]; then
                if ! validate_archive "$latest_backup"; then
                    validation_result=0
                    host_status=0
                fi
            fi

            # Загрузка в S3 (только если бэкап валиден)
            if [ "$host_status" -eq 1 ]; then
                if upload_to_s3 "$latest_backup"; then
                    upload_status=1
                    ((total_uploaded++))
                else
                    ((total_failed++))
                fi
            fi

            # Записываем метрики
            cat >> "$tmp_metrics" <<EOF
backup_last_timestamp_seconds{host="$hostname"} $backup_time
backup_age_seconds{host="$hostname"} $backup_age
backup_size_bytes{host="$hostname"} $backup_size
backup_count_total{host="$hostname"} $backup_count
backup_validation_result{host="$hostname"} $validation_result
backup_s3_upload_status{host="$hostname"} $upload_status
EOF
        else
            log "ERROR" "Бэкапы не найдены для хоста $hostname"
            host_status=0
        fi

        echo "backup_status{host=\"$hostname\"} $host_status" >> "$tmp_metrics"

        # Глобальный статус
        [ "$host_status" -eq 0 ] && global_status=1
    done

    # Дополнительные метрики
    echo "# HELP backup_s3_upload_total Total S3 uploads" >> "$tmp_metrics"
    echo "# TYPE backup_s3_upload_total counter" >> "$tmp_metrics"
    echo "backup_s3_upload_total{type=\"success\"} $total_uploaded" >> "$tmp_metrics"
    echo "backup_s3_upload_total{type=\"failed\"} $total_failed" >> "$tmp_metrics"

    # Сохраняем метрики
    mv "$tmp_metrics" "$METRICS_FILE"

    # Отправка в Pushgateway
    if [ -n "$PROMETHEUS_GATEWAY" ]; then
        log "DEBUG" "Отправка метрик в Prometheus Pushgateway"
        if ! curl -X POST --data-binary @"$METRICS_FILE" \
             "$PROMETHEUS_GATEWAY/metrics/job/backup_validator/instance/$(hostname)"; then
            log "ERROR" "Ошибка отправки метрик в Pushgateway"
        fi
    fi

    return $global_status
}

# Проверка зависимостей
check_dependencies() {
    if ! command -v "$YC_CLI" &>/dev/null; then
        log "ERROR" "YC CLI не установлен. Установите: https://cloud.yandex.ru/docs/cli/quickstart"
        exit 1
    fi
}

# Главный блок
rotate_logs
check_dependencies

log "INFO" "=== Запуск валидатора бэкапов ==="
log "INFO" "Параметры:"
log "INFO" "  BACKUP_ROOT: $BACKUP_ROOT"
log "INFO" "  MAX_AGE_HOURS: $MAX_AGE_HOURS"
log "INFO" "  VALIDATE_ARCHIVE: $VALIDATE_ARCHIVE"
log "INFO" "  MIN_BACKUP_COUNT: $MIN_BACKUP_COUNT"
log "INFO" "  S3_BUCKET: $S3_BUCKET"
log "INFO" "  S3_PREFIX: $S3_PREFIX"

if validate_and_upload_backups; then
    log "INFO" "Проверка и загрузка завершены успешно"
    exit 0
else
    log "ERROR" "Проверка завершена с ошибками"
    exit 1
fi
