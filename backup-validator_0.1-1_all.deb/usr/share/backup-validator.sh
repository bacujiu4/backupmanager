#!/bin/bash

# Конфигурация
BACKUP_ROOT="/root/backup"
PROMETHEUS_GATEWAY="http://prometheus.vpn:9091"
METRICS_FILE="/var/lib/node_exporter/backup_metrics.prom"
LOG_FILE="/var/log/backup_validator.log"
MAX_LOG_FILES=5
MAX_LOG_SIZE=10M
MAX_AGE_HOURS=24
VALIDATE_ARCHIVE=true  # Проверять целостность архивов
MIN_BACKUP_COUNT=1     # Минимальное количество бэкапов для каждого хоста

# Инициализация логов
mkdir -p "$(dirname "$LOG_FILE")"
exec > >(tee -a "$LOG_FILE") 2>&1

# Функция ротации логов
rotate_logs() {
    if [ -f "$LOG_FILE" ] && [ $(stat -c%s "$LOG_FILE") -gt $(numfmt --from=iec "$MAX_LOG_SIZE") ]; then
        for i in $(seq $((MAX_LOG_FILES-1)) -1 1); do
            [ -f "${LOG_FILE}.$i" ] && mv "${LOG_FILE}.$i" "${LOG_FILE}.$((i+1))"
        done
        mv "$LOG_FILE" "${LOG_FILE}.1"
    fi
}

# Функция логирования с разными уровнями
log() {
    local level=$1
    local message=$2
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S,%3N")
    echo "[$timestamp] [$level] $message" | tee -a "$LOG_FILE"
}

# Функция проверки целостности архива
validate_archive() {
    local archive_path=$1
    log "DEBUG" "Проверка целостности архива: $archive_path"
    
    if ! tar -tzf "$archive_path" >/dev/null 2>&1; then
        log "ERROR" "Архив поврежден: $archive_path"
        return 1
    fi
    
    # Дополнительные проверки
    local file_count=$(tar -tzf "$archive_path" | wc -l)
    if [ "$file_count" -lt 5 ]; then
        log "WARNING" "Мало файлов в архиве ($file_count): $archive_path"
    fi
    
    return 0
}

# Основная функция валидации
validate_backups() {
    local current_time=$(date +%s)
    local global_status=0
    local tmp_metrics=$(mktemp)
    
    # Заголовки метрик
    cat > "$tmp_metrics" <<EOF
# HELP backup_last_timestamp_seconds Timestamp of last backup
# TYPE backup_last_timestamp_seconds gauge
# HELP backup_status Backup status (1 - OK, 0 - problem)
# TYPE backup_status gauge
# HELP backup_age_seconds Age of last backup in seconds
# TYPE backup_age_seconds gauge
# HELP backup_size_bytes Size of last backup in bytes
# TYPE backup_size_bytes gauge
# HELP backup_count_total Number of backups for host
# TYPE backup_count_total gauge
# HELP backup_validation_result Archive validation result (1 - valid, 0 - invalid)
# TYPE backup_validation_result gauge
EOF

    log "INFO" "Начало проверки бэкапов в $BACKUP_ROOT"
    
    # Обработка каждого каталога с бэкапами
    for host_dir in "$BACKUP_ROOT"/*; do
        [ -d "$host_dir" ] || continue
        
        local hostname=$(basename "$host_dir")
        local backups=($(find "$host_dir" -name "backup_${hostname}_*.tar.gz" -type f -printf "%T@ %p\n" | sort -nr | cut -d' ' -f2))
        local backup_count=${#backups[@]}
        local host_status=1
        
        log "INFO" "Проверка хоста: $hostname (найдено бэкапов: $backup_count)"
        
        if [ "$backup_count" -lt "$MIN_BACKUP_COUNT" ]; then
            log "ERROR" "Недостаточно бэкапов для $hostname (ожидается $MIN_BACKUP_COUNT, найдено $backup_count)"
            host_status=0
        fi

        # Проверяем последний бэкап
        if [ "$backup_count" -gt 0 ]; then
            local latest_backup="${backups[0]}"
            local backup_time=$(stat -c %Y "$latest_backup")
            local backup_age=$((current_time - backup_time))
            local backup_size=$(stat -c %s "$latest_backup")
            local validation_result=1
            
            log "INFO" "Последний бэкап: $(basename "$latest_backup")"
            log "INFO" "Размер: $backup_size байт, возраст: $((backup_age/3600)) ч. $(( (backup_age%3600)/60 )) мин."
            
            # Проверка возраста
            if [ "$backup_age" -gt $((MAX_AGE_HOURS * 3600)) ]; then
                log "ERROR" "Бэкап слишком старый: $((backup_age/3600)) часов"
                host_status=0
            fi
            
            # Проверка целостности
            if [ "$VALIDATE_ARCHIVE" = true ]; then
                if ! validate_archive "$latest_backup"; then
                    validation_result=0
                    host_status=0
                fi
            fi
            
            # Записываем метрики
            cat >> "$tmp_metrics" <<EOF
backup_last_timestamp_seconds{host="$hostname"} $backup_time
backup_age_seconds{host="$hostname"} $backup_age
backup_size_bytes{host="$hostname"} $backup_size
backup_count_total{host="$hostname"} $backup_count
backup_validation_result{host="$hostname"} $validation_result
EOF
        else
            log "ERROR" "Бэкапы не найдены для хоста $hostname"
            host_status=0
        fi
        
        echo "backup_status{host=\"$hostname\"} $host_status" >> "$tmp_metrics"
        
        # Глобальный статус
        [ "$host_status" -eq 0 ] && global_status=1
    done
    
    # Сохраняем метрики
    mv "$tmp_metrics" "$METRICS_FILE"
    
    # Отправка в Pushgateway
    if [ -n "$PROMETHEUS_GATEWAY" ]; then
        log "DEBUG" "Отправка метрик в Prometheus Pushgateway"
        if ! curl -X POST --data-binary @"$METRICS_FILE" \
             "$PROMETHEUS_GATEWAY/metrics/job/backup_validator/instance/$(hostname)"; then
            log "ERROR" "Ошибка отправки метрик в Pushgateway"
        fi
    fi
    
    return $global_status
}

# Главный блок
rotate_logs
log "INFO" "=== Запуск валидатора бэкапов ==="
log "INFO" "Параметры:"
log "INFO" "  BACKUP_ROOT: $BACKUP_ROOT"
log "INFO" "  MAX_AGE_HOURS: $MAX_AGE_HOURS"
log "INFO" "  VALIDATE_ARCHIVE: $VALIDATE_ARCHIVE"
log "INFO" "  MIN_BACKUP_COUNT: $MIN_BACKUP_COUNT"

if validate_backups; then
    log "INFO" "Проверка завершена успешно"
    exit 0
else
    log "ERROR" "Проверка завершена с ошибками"
    exit 1
fi
